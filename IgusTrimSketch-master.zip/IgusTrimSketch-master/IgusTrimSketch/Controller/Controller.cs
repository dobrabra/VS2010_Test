﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IgusTrimSketch.Views;

namespace IgusTrimSketch
{
    public partial class Controller : Form
    {
        foMainView viewTrimGroups;
        dataBase model;
 
        public Controller()
        {
            InitializeComponent();
            this.Visible = false;
            this.Hide();

            model = new dataBase();
            
            viewTrimGroups = new foMainView(this,model);
            viewTrimGroups.Show();
        }
    }
}

