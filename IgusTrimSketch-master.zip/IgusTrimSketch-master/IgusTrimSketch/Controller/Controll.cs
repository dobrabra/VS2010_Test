﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IgusTrimSketch
{
    public class Controller
    {
        foMainView viewTrimGroups;
        dataBase model;
        DatabasePersist xmlPersist;

        public Controller()
        {
            xmlPersist = new DatabasePersist();

            model = new dataBase(xmlPersist);

            viewTrimGroups = new foMainView(this, model);
            viewTrimGroups.ShowDialog();
        }
    }
}
