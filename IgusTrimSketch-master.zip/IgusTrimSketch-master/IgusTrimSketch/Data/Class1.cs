﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IgusTrimSketch
{

    public class Machine
    {
        public string name;
        public string ipaddress;
        public int lco;

        public Machine(string name, string ipaddress, int lco)
        {
            this.name = name;
            this.ipaddress = ipaddress;
            this.lco = lco;
        }

        public Machine()
        {

        }

    }

    public class MachineList
    {
        public string name;
        public List<Machine> machines;
       
        public MachineList(string name)
        {
            this.name = name;
            machines = new List<Machine>();
        }

        public MachineList()
        {
            machines = new List<Machine>();
        }

  
        public void AddMachine(Machine nr)
        {
            machines.Add(nr);
        }

    }


    //public class TrimTriple
    //{
    //    public int nr;
    //    public int trim;
    //    public int diameter;

    //    public TrimTriple(int n, int t, int d)
    //    {
    //        nr = n;
    //        trim = t;
    //        diameter = d;

    //    }

    //    public TrimTriple()
    //    {

    //    }

    //}

    //public class TrimSet
    //{
    //    public string name;
    //    public TrimTriple[] TrimTriples;

    //    public TrimSet(string name, int type)
    //    {
    //        this.name = name;
    //        TrimTriples = new TrimTriple[32];
    //        TrimTriple tt = new TrimTriple(1,2,3);
    //        for (int i = 0; i < 32; i++)
    //        {
    //            if (type==1)
    //                TrimTriples[i] = new TrimTriple(i+1,i+2,i+3);
    //            else
    //                TrimTriples[i] = new TrimTriple(i + 1, i + 3, i + 2);

    //        }
    //    }

    //    public TrimSet()
    //    {

    //    }

    //}

    //public class TrimGroup
    //{
    //    public string name;
    //    public string machineListname;
    //    public string trimSetName;

    //    public List<int> machines;
    //    public MachineList machineList;
    //    public TrimSet trims;

    //    public TrimGroup(string name, string machineListname, string trimSetName)
    //    {
    //        this.name = name;
    //        this.machineListname = machineListname;
    //        this.trimSetName = trimSetName;

    //        machines = new List<int>();
    //    }


    //    public TrimGroup()
    //    {

    //    }

    //    public void setTrimset(TrimSet ts)
    //    {
    //        trims = ts;
    //    }

    //    public void AddMachine(int nr)
    //    {
    //        machines.Add(nr);
    //    }

    //}

}
