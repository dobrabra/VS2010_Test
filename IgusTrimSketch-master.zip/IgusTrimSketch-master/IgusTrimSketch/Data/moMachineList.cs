﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IgusTrimSketch
{

    public class Machine
    {
        public string name;
        public string ipaddress;
        public int lco;

        public Machine(string name, string ipaddress, int lco)
        {
            this.name = name;
            this.ipaddress = ipaddress;
            this.lco = lco;
        }

        public Machine()
        {

        }

    }

    public class MachineList
    {
        public string name;
        public List<Machine> machines;
       
        public MachineList(string name)
        {
            this.name = name;
            machines = new List<Machine>();
        }

        public MachineList()
        {
            machines = new List<Machine>();
        }

  
        public void AddMachine(Machine nr)
        {
            machines.Add(nr);
        }

    }


}
