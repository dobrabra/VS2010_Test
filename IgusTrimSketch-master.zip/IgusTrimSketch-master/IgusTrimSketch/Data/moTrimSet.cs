﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IgusTrimSketch
{

    public class TrimTriple
    {
        public int nr;
        public int trim;
        public int diameter;

        public TrimTriple(int n, int t, int d)
        {
            nr = n;
            trim = t;
            diameter = d;

        }

        public TrimTriple()
        {

        }

    }

    public class TrimSet
    {
        public string name;
        public TrimTriple[] TrimTriples;

        public TrimSet(string name, int type)
        {
            this.name = name;
            TrimTriples = new TrimTriple[32];
            TrimTriple tt = new TrimTriple(1,2,3);
            for (int i = 0; i < 32; i++)
            {
                if (type==1)
                    TrimTriples[i] = new TrimTriple(i+1,i+2,i+3);
                else
                    TrimTriples[i] = new TrimTriple(i + 1, i + 3, i + 2);

            }
        }

        public TrimSet()
        {

        }

    }

}
