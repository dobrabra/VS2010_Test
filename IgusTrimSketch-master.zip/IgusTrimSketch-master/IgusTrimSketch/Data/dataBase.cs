﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace IgusTrimSketch
{
    public class dataBase
    {
        public MachineList machines = new MachineList("MachineList");
        public List<MachineList> machineList = new List<MachineList>();

        public List<TrimSet> trimsetList= new List<TrimSet>();
        public List<TrimGroup> trimGroupList = new List<TrimGroup>();

        DatabasePersist _persist;
        public dataBase(DatabasePersist persist)
        {
            _persist = persist;

            try
            {
                _persist.loadDatabase(this);
            }
            catch (Exception)
            {
                MachineList ml = new MachineList("MachineList 1");
                ml.AddMachine(new Machine("M1", "192.168.3.134", 1));
                ml.AddMachine(new Machine("M2", "192.168.3.134", 2));
                ml.AddMachine(new Machine("M3", "192.168.3.134", 3));

                machineList.Add(ml);

                ml = new MachineList("MachineList 2");
                ml.AddMachine(new Machine("M4", "192.168.3.135", 1));
                ml.AddMachine(new Machine("M5", "192.168.3.135", 2));
                ml.AddMachine(new Machine("M6", "192.168.3.135", 3));

                machineList.Add(ml);

                trimsetList.Add(new TrimSet("Trimset 1", 0));
                trimsetList.Add(new TrimSet("Trimset 2", 1));
                trimsetList.Add(new TrimSet("Trimset 3", 1));

                trimGroupList.Add(new TrimGroup("TrimGroup1", "MachineList 1", "Trimset 1"));
                trimGroupList.Add(new TrimGroup("TrimGroup2", "MachineList 2", "Trimset 2"));
            }

        }

        public void saveDatabase()
        {
            _persist.saveDatabase(this);
        }
    }


    //    public void saveDatabase()
    //    {
    //        XmlSerializer xsSubmit = new XmlSerializer(typeof(List<MachineList>), new XmlRootAttribute("MachineLists"));
    //        using (FileStream str = new FileStream(@"Machines.xml", FileMode.Create))
    //        {
    //            xsSubmit.Serialize(str, machineList);
    //        }

        //        xsSubmit = new XmlSerializer(typeof(List<TrimSet>), new XmlRootAttribute("TrimSets"));
        //        using (FileStream str = new FileStream(@"TrimSets.xml", FileMode.Create))
        //        {
        //            xsSubmit.Serialize(str, trimsetList);
        //        }

        //        xsSubmit = new XmlSerializer(typeof(List<TrimGroup>), new XmlRootAttribute("TrimGroups"));
        //        using (FileStream str = new FileStream(@"TrimGroups.xml", FileMode.Create))
        //        {
        //            xsSubmit.Serialize(str, trimGroupList);
        //        }

        //    }
        //    public void loadDatabase()
        //    {
        //        XmlSerializer xsSubmit = new XmlSerializer(typeof(List<MachineList>), new XmlRootAttribute("MachineLists"));
        //        using (FileStream str = new FileStream(@"Machines.xml", FileMode.Open))
        //        {
        //            machineList = (List<MachineList>)xsSubmit.Deserialize(str);
        //        }

        //        xsSubmit = new XmlSerializer(typeof(List<TrimSet>), new XmlRootAttribute("TrimSets"));
        //        using (FileStream str = new FileStream(@"TrimSets.xml", FileMode.Open))
        //        {
        //            trimsetList = (List<TrimSet>)xsSubmit.Deserialize(str);
        //        }

        //        xsSubmit = new XmlSerializer(typeof(List<TrimGroup>), new XmlRootAttribute("TrimGroups"));
        //        using (FileStream str = new FileStream(@"TrimGroups.xml", FileMode.Open))
        //        {
        //            trimGroupList = (List<TrimGroup>)xsSubmit.Deserialize(str);
        //        }

        //    }
        //

}
