﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace IgusTrimSketch
{
    public class DatabasePersist : IDatabasePersist
    {
        public void loadDatabase(dataBase db)
        {
            XmlSerializer xsSubmit = new XmlSerializer(typeof(List<MachineList>), new XmlRootAttribute("MachineLists"));
            using (FileStream str = new FileStream(@"Machines.xml", FileMode.Open))
            {
                db.machineList = (List<MachineList>)xsSubmit.Deserialize(str);
            }

            xsSubmit = new XmlSerializer(typeof(List<TrimSet>), new XmlRootAttribute("TrimSets"));
            using (FileStream str = new FileStream(@"TrimSets.xml", FileMode.Open))
            {
                db.trimsetList = (List<TrimSet>)xsSubmit.Deserialize(str);
            }

            xsSubmit = new XmlSerializer(typeof(List<TrimGroup>), new XmlRootAttribute("TrimGroups"));
            using (FileStream str = new FileStream(@"TrimGroups.xml", FileMode.Open))
            {
                db.trimGroupList = (List<TrimGroup>)xsSubmit.Deserialize(str);
            }
        }

        public void saveDatabase(dataBase db)
        {
            XmlSerializer xsSubmit = new XmlSerializer(typeof(List<MachineList>), new XmlRootAttribute("MachineLists"));
            using (FileStream str = new FileStream(@"Machines.xml", FileMode.Create))
            {
                xsSubmit.Serialize(str, db.machineList);
            }

            xsSubmit = new XmlSerializer(typeof(List<TrimSet>), new XmlRootAttribute("TrimSets"));
            using (FileStream str = new FileStream(@"TrimSets.xml", FileMode.Create))
            {
                xsSubmit.Serialize(str, db.trimsetList);
            }

            xsSubmit = new XmlSerializer(typeof(List<TrimGroup>), new XmlRootAttribute("TrimGroups"));
            using (FileStream str = new FileStream(@"TrimGroups.xml", FileMode.Create))
            {
                xsSubmit.Serialize(str, db.trimGroupList);
            }
        }
    }
}
