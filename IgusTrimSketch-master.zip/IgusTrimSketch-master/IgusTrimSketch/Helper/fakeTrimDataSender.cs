﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace IgusTrimSketch
{
    public static class fakeTrimDataSender
    {
        public static bool senderIsBusy;
        public static void SendTrimData(MachineList ml, TrimSet trimset)
        {
            senderIsBusy = true;
            var builder = new StringBuilder();

            foreach (var m in ml.machines)
            {
                Console.WriteLine(m.ipaddress + ':' + m.lco.ToString());
 
                foreach (var ts in trimset.TrimTriples)
                {
                    builder.AppendFormat("{0}, {1}, {2}", ts.nr, ts.trim, ts.diameter);

                }
                Console.WriteLine("Data: ");
                Console.Write(builder.ToString());
                Console.WriteLine();
            }
            Thread.Sleep(1000);
        }
    }
}
