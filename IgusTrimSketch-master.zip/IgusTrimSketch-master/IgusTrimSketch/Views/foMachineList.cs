﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch
{
    public partial class foMachineList : Form
    {

  
        //private DataGridView trimsDataGridView = new DataGridView();
        //private Button addNewRowButton = new Button();
        //private Button deleteRowButton = new Button();
        //private Button nextTrimSetButton = new Button();

        dataBase _db;
       int actualMachineList;
       


        public foMachineList(dataBase db)
        {
            InitializeComponent();

            _db = db;

            this.Load += new EventHandler(Form1_Load);

        }

        private void Form1_Load(System.Object sender, System.EventArgs e)
        {
            SetupLayout();
            SetupDataGridView();
            PopulateDataGridView(0);
        }


        private void trimsDataGridView_CellFormatting(object sender, System.Windows.Forms.DataGridViewCellFormattingEventArgs e)
        {
            if (e != null)
            {
                if (this.trimsDataGridView.Columns[e.ColumnIndex].Name == "Release Date")
                {
                    if (e.Value != null)
                    {
                        try
                        {
                            e.Value = DateTime.Parse(e.Value.ToString())
                                .ToLongDateString();
                            e.FormattingApplied = true;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("{0} is not a valid date.", e.Value.ToString());
                        }
                    }
                }
            }
        }

        private void addNewRowButton_Click(object sender, EventArgs e)
        {
            this.trimsDataGridView.Rows.Add();
        }

        private void deleteRowButton_Click(object sender, EventArgs e)
        {
            if (this.trimsDataGridView.SelectedRows.Count > 0 &&
                this.trimsDataGridView.SelectedRows[0].Index !=
                this.trimsDataGridView.Rows.Count - 1)
            {
                this.trimsDataGridView.Rows.RemoveAt(
                    this.trimsDataGridView.SelectedRows[0].Index);
            }
        }

        private void SetupLayout()
        {
            //this.Size = new Size(600, 500);

            //addNewRowButton.Text = "Add Row";
            //addNewRowButton.Location = new Point(10, 10);
            //addNewRowButton.Click += new EventHandler(addNewRowButton_Click);

            //deleteRowButton.Text = "Delete Row";
            //deleteRowButton.Location = new Point(100, 10);
            //deleteRowButton.Click += new EventHandler(deleteRowButton_Click);

            //nextTrimSetButton.Text = "Next Trimset";
            //nextTrimSetButton.Location = new Point(150, 10);
            //nextTrimSetButton.Click += new EventHandler(nextTrimSetButton_Click);


            //buttonPanel.Controls.Add(addNewRowButton);
            //buttonPanel.Controls.Add(deleteRowButton);
            //buttonPanel.Controls.Add(nextTrimSetButton);
            //buttonPanel.Height = 50;
            //buttonPanel.Dock = DockStyle.Bottom;

            //this.Controls.Add(this.buttonPanel);
        }

        private void nextTrimSetButton_Click(object sender, EventArgs e)
        {
            if (actualMachineList < _db.machineList.Count-1)
                actualMachineList++;
            else
                actualMachineList = 0;

            PopulateDataGridView(actualMachineList);

            this.Text = _db.trimGroupList[actualMachineList].name;
        }

        private void SetupDataGridView()
        {
            this.Controls.Add(trimsDataGridView);

            trimsDataGridView.ColumnCount = 3;

            trimsDataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            trimsDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            trimsDataGridView.ColumnHeadersDefaultCellStyle.Font =
                new Font(trimsDataGridView.Font, FontStyle.Bold);

            trimsDataGridView.Name = "trimsDataGridView";
            trimsDataGridView.Location = new Point(8, 8);
            trimsDataGridView.Size = new Size(500, 250);
            trimsDataGridView.AutoSizeRowsMode =
                DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            trimsDataGridView.ColumnHeadersBorderStyle =
                DataGridViewHeaderBorderStyle.Single;
            trimsDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            trimsDataGridView.GridColor = Color.Black;
            trimsDataGridView.RowHeadersVisible = false;

            trimsDataGridView.Columns[0].Name = "Trimgruppe";
            trimsDataGridView.Columns[1].Name = "Maschinenliste";
            trimsDataGridView.Columns[2].Name = "Trimset";

            trimsDataGridView.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            trimsDataGridView.MultiSelect = false;
            trimsDataGridView.Dock = DockStyle.Fill;

            trimsDataGridView.CellFormatting += new
                DataGridViewCellFormattingEventHandler(
                trimsDataGridView_CellFormatting);
        }

        private void PopulateDataGridView(int actualMachineList)
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < _db.trimGroupList[actualMachineList].machines.Count; i++) {
                row[0] = _db.trimGroupList[actualMachineList].name;
                row[1] = _db.trimGroupList[actualMachineList].machineListname;
                row[2] = _db.trimGroupList[actualMachineList].trimSetName;

                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }   

    

        }

 

  
    }
}
