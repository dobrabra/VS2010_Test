﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foSelectMachineList : Form
    {
        public string selectedItem;
        public foSelectMachineList(List<MachineList> ml)
        {
            InitializeComponent();
            foreach (var item in ml)
            {
                listBox1.Items.Add(item.name);
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            selectedItem = listBox1.SelectedItem.ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}
