﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foEditTrimSet : Form
    {
        dataBase _db;
        bool dontClose = false;
        bool newItem = false;
        int _index = 0;

        public foEditTrimSet()
        {
            InitializeComponent();
        }

        public foEditTrimSet(dataBase db)
        {
            InitializeComponent();
            _db = db;
            PopulateDataGridView(1);
            newItem = true;

        }

        public foEditTrimSet(dataBase db, int index)
        {
            InitializeComponent();
            _db = db;
            _index = index;
            SetActualValues(_index);
        }

        private void SetActualValues(int idx)
        {
            PopulateDataGridView(idx);
            tbxName.Text= _db.trimsetList[idx].name;
        }
        
        private void PopulateDataGridView(int actualTrimset)
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < 32; i++)
            {
                row[0] = _db.trimsetList[actualTrimset].TrimTriples[i].nr.ToString();
                row[1] = _db.trimsetList[actualTrimset].TrimTriples[i].diameter.ToString();
                row[2] = _db.trimsetList[actualTrimset].TrimTriples[i].trim.ToString();

                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }
        }
        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            dontClose = false;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            int i = 0;
            dontClose = tbxName.Text == "";

            if (dontClose)
            {
                MessageBox.Show("Bitte Maschinenliste und Trimrezept wählen !");
            }

            else
            {
                if (newItem)
                {
                    ;
                }
                else
                {
                    foreach (DataGridViewRow item in trimsDataGridView.Rows)
                    {
                        if (i < 32)  //Todo PATCH
                        {
                            _db.trimsetList[_index].TrimTriples[i].diameter = Convert.ToInt16(item.Cells[1].Value);
                            _db.trimsetList[_index].TrimTriples[i].trim = Convert.ToInt16(item.Cells[2].Value);
                        }
                        i++;
                    }
                    _db.trimsetList[_index].name = tbxName.Text;
                }
                _db.saveDatabase();
            }
        }

        private void foEditGroup_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (dontClose)
            {
                e.Cancel = true;
            }
        }
    }
}
