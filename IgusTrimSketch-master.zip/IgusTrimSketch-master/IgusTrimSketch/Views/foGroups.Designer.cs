﻿namespace IgusTrimSketch.Views
{
    partial class foGroups
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.trimsDataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sendTrimButton = new System.Windows.Forms.Button();
            this.deleteRowButton = new System.Windows.Forms.Button();
            this.addNewRowButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trimsDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // trimsDataGridView
            // 
            this.trimsDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.trimsDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.trimsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.trimsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(4);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.trimsDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.trimsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trimsDataGridView.EnableHeadersVisualStyles = false;
            this.trimsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.trimsDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.trimsDataGridView.Name = "trimsDataGridView";
            this.trimsDataGridView.RowHeadersVisible = false;
            this.trimsDataGridView.RowTemplate.Height = 30;
            this.trimsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.trimsDataGridView.Size = new System.Drawing.Size(377, 229);
            this.trimsDataGridView.TabIndex = 15;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Trimgruppe";
            this.Column1.Name = "Column1";
            this.Column1.Width = 120;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Maschinenliste";
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Trimrezept";
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.sendTrimButton);
            this.panel1.Controls.Add(this.deleteRowButton);
            this.panel1.Controls.Add(this.addNewRowButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 164);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(377, 65);
            this.panel1.TabIndex = 16;
            // 
            // sendTrimButton
            // 
            this.sendTrimButton.AutoSize = true;
            this.sendTrimButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.sendTrimButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendTrimButton.Location = new System.Drawing.Point(239, 14);
            this.sendTrimButton.Margin = new System.Windows.Forms.Padding(4);
            this.sendTrimButton.Name = "sendTrimButton";
            this.sendTrimButton.Padding = new System.Windows.Forms.Padding(4);
            this.sendTrimButton.Size = new System.Drawing.Size(131, 36);
            this.sendTrimButton.TabIndex = 2;
            this.sendTrimButton.Text = "Sende Trimdaten";
            this.sendTrimButton.UseVisualStyleBackColor = true;
            // 
            // deleteRowButton
            // 
            this.deleteRowButton.AutoSize = true;
            this.deleteRowButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.deleteRowButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteRowButton.Location = new System.Drawing.Point(129, 14);
            this.deleteRowButton.Margin = new System.Windows.Forms.Padding(4);
            this.deleteRowButton.Name = "deleteRowButton";
            this.deleteRowButton.Padding = new System.Windows.Forms.Padding(4);
            this.deleteRowButton.Size = new System.Drawing.Size(108, 36);
            this.deleteRowButton.TabIndex = 1;
            this.deleteRowButton.Text = "Zeile löschen";
            this.deleteRowButton.UseVisualStyleBackColor = true;
            // 
            // addNewRowButton
            // 
            this.addNewRowButton.AutoSize = true;
            this.addNewRowButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.addNewRowButton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNewRowButton.Location = new System.Drawing.Point(10, 14);
            this.addNewRowButton.Margin = new System.Windows.Forms.Padding(4);
            this.addNewRowButton.Name = "addNewRowButton";
            this.addNewRowButton.Padding = new System.Windows.Forms.Padding(4);
            this.addNewRowButton.Size = new System.Drawing.Size(116, 36);
            this.addNewRowButton.TabIndex = 0;
            this.addNewRowButton.Text = "Zeile einfügen";
            this.addNewRowButton.UseVisualStyleBackColor = true;
            // 
            // foGroups
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 229);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.trimsDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "foGroups";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "foGroups";
            ((System.ComponentModel.ISupportInitialize)(this.trimsDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView trimsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button sendTrimButton;
        private System.Windows.Forms.Button deleteRowButton;
        private System.Windows.Forms.Button addNewRowButton;
    }
}