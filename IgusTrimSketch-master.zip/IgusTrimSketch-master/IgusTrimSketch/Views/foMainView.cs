﻿using IgusTrimSketch.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace IgusTrimSketch


{
    public partial class foMainView : Form
    {
        dataBase _db;
        Controller _controller;
  
        public foMainView(Controller c, dataBase db)
        {
            _controller = c;
            _db = db;
            InitializeComponent();

            ucGroups1.Initialise(_controller, _db);
            ucMachineLists1.Initialise(_controller, _db);
            ucTrendRecipes1.Initialise(_controller, _db);
        }

    }
}
