﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class ucTrendRecipes : UserControl
    {
        #region Members
        dataBase _db;
        Controller _controller;
        #endregion

        #region Constructors
        public ucTrendRecipes()
        {
            InitializeComponent();
        }

        public ucTrendRecipes(Controller c, dataBase db)
        {
            _controller = c;
            _db = db;
            InitializeComponent();
            PopulateDataGridView();
        }
        #endregion

        public void Initialise(Controller c, dataBase db)
        {
            _controller = c;
            _db = db;
            PopulateDataGridView();
        }

        #region User events
        private void addNewRowButton_Click(object sender, EventArgs e)
        {
            _db.trimGroupList.Add(new TrimGroup("...", "...", "..."));
            PopulateDataGridView();
        }

        private void deleteRowButton_Click(object sender, EventArgs e)
        {
            _db.trimGroupList.RemoveAt(trimsDataGridView.SelectedRows[0].Index);
            PopulateDataGridView();
        }

 
        private void nextTrimSetButton_Click(object sender, EventArgs e)
        {
            _db.saveDatabase();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            foEditTrimSet editDialog = new foEditTrimSet(_db, trimsDataGridView.SelectedRows[0].Index);
            editDialog.ShowDialog();


            PopulateDataGridView();
        }
        #endregion

        private void PopulateDataGridView()
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < _db.trimsetList.Count; i++)
            {
                row[0] = _db.trimsetList[i].name;
                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }
        }
    }        
}
